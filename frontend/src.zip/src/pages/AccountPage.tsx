import React, { useState } from 'react';
import {
  ShieldCheck,
  Download,
  Trash2,
  Sun,
  Moon,
  Check,
} from 'lucide-react';

import { usePreferences, useLibrary } from '../context';
import { PersonalNav } from '../components/personal';
import {
  PageContainer,
  SectionHeader,
  GlassPanel,
  Button,
  StateSwitcher,
  usePageState,
  LoadingState,
  EmptyState,
  ErrorState,
} from '../components/ui';

export const AccountPage: React.FC = () => {
  const [pageState, setPageState] = usePageState('populated');
  const [sessionSaved, setSessionSaved] = useState(false);
  const [resetConfirmed, setResetConfirmed] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  const {
    tasteState,
    recommendationPreferences,
    profileState,
    accountPreferences,
    updateAccountPreferences,
    resetTastePreferences,
  } = usePreferences();

  const { watchlistIds, favouriteIds, historyIds } = useLibrary();

  const notify = (msg: string) => {
    setFeedbackMessage(msg);
    setTimeout(() => setFeedbackMessage(null), 2500);
  };

  const handleExportDNA = () => {
    const exportData = {
      version: '1.0.0-phase1',
      curator: profileState.displayName,
      exportedAt: new Date().toISOString(),
      tasteSignals: tasteState,
      recommendationCalibrations: recommendationPreferences,
      libraryRecords: {
        watchlistIds,
        favouriteIds,
        historyIds,
      },
      accountSettings: accountPreferences,
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `veya-luma-cinematic-dna-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setSessionSaved(true);
    notify('Cinematic DNA exported successfully as JSON.');
    setTimeout(() => setSessionSaved(false), 3000);
  };

  const handleResetVectors = () => {
    resetTastePreferences();
    setResetConfirmed(true);
    notify('Taste vectors successfully reset to baseline.');
    setTimeout(() => setResetConfirmed(false), 3000);
  };

  return (
    <PageContainer maxWidth="standard" paddingY="md" withAtmosphere>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <SectionHeader
          as="h1"
          eyebrow="SANCTUARY & CREDENTIALS"
          title="Account & Privacy"
          description="Manage your local discovery profile, privacy boundaries, and vector retention policies."
          className="mb-0"
        />
        <StateSwitcher state={pageState} onStateChange={setPageState} />
      </div>

      {/* Personal Sub-Navigation */}
      <PersonalNav />

      {/* Notification Banner */}
      {feedbackMessage && (
        <div
          role="status"
          className="mb-6 p-3 rounded-xl bg-luminous-cyan/15 border border-luminous-cyan/30 text-luminous-cyan text-xs flex items-center gap-2 animate-fadeIn"
        >
          <Check className="w-4 h-4" />
          <span>{feedbackMessage}</span>
        </div>
      )}

      {pageState === 'loading' && (
        <LoadingState type="cards" count={2} message="Loading account sanctuary parameters..." />
      )}

      {pageState === 'error' && (
        <ErrorState
          title="Account Settings Unavailable"
          message="Could not load your local account profile settings."
          onRetry={() => setPageState('populated')}
        />
      )}

      {pageState === 'empty' && (
        <EmptyState
          title="No Active Profile Record"
          description="Your local session has no persistent account profile configured."
          action={
            <Button size="sm" onClick={() => setPageState('populated')}>
              Create Local Profile
            </Button>
          }
        />
      )}

      {pageState === 'populated' && (
        <div className="max-w-3xl space-y-6 font-sans">
          {/* Appearance & Base Theme Settings */}
          <GlassPanel elevation="plate" padding="lg" rounded="2xl" className="space-y-4">
            <div>
              <h3 className="font-editorial text-xl font-bold text-white mb-1">
                Appearance & Theme
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Choose your cinematic environment. Deep obsidian space is tuned for visual immersion; high-contrast light mode optimizes daylight reading.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  updateAccountPreferences({ baseTheme: 'dark' });
                  notify('Base theme set to Dark (Obsidian Void).');
                }}
                className={`flex items-start gap-3 p-4 rounded-xl border text-left transition-all ${
                  accountPreferences.baseTheme === 'dark'
                    ? 'bg-luminous-cyan/10 border-luminous-cyan text-white shadow-cyan-glow'
                    : 'bg-obsidian-surface border-white/5 text-slate-300 hover:border-white/20'
                }`}
                aria-pressed={accountPreferences.baseTheme === 'dark'}
              >
                <div className="w-8 h-8 rounded-lg bg-obsidian-base border border-white/10 flex items-center justify-center shrink-0 text-luminous-cyan">
                  <Moon className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-xs font-semibold">Dark Theme</span>
                    {accountPreferences.baseTheme === 'dark' && (
                      <span className="text-[10px] uppercase font-bold text-luminous-cyan">Active</span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-400 block leading-tight">
                    Signature Obsidian Void palette with subtle luminous accents.
                  </span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  updateAccountPreferences({ baseTheme: 'light' });
                  notify('Base theme set to Light (High-Contrast Editorial).');
                }}
                className={`flex items-start gap-3 p-4 rounded-xl border text-left transition-all ${
                  accountPreferences.baseTheme === 'light'
                    ? 'bg-luminous-cyan/10 border-luminous-cyan text-white shadow-cyan-glow'
                    : 'bg-obsidian-surface border-white/5 text-slate-300 hover:border-white/20'
                }`}
                aria-pressed={accountPreferences.baseTheme === 'light'}
              >
                <div className="w-8 h-8 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center shrink-0 text-luminous-amber">
                  <Sun className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-xs font-semibold">Light Theme</span>
                    {accountPreferences.baseTheme === 'light' && (
                      <span className="text-[10px] uppercase font-bold text-luminous-cyan">Active</span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-400 block leading-tight">
                    High optical contrast for illuminated viewing environments.
                  </span>
                </div>
              </button>
            </div>
          </GlassPanel>

          {/* Interface & Accessibility Preferences */}
          <GlassPanel elevation="plate" padding="lg" rounded="2xl" className="space-y-4">
            <div>
              <h3 className="font-editorial text-xl font-bold text-white mb-1">
                Interface & Accessibility
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Fine-tune interaction pacing, motion effects, and catalog presentation density.
              </p>
            </div>

            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-obsidian-surface border border-white/5">
                <div>
                  <span className="text-xs font-semibold text-white block">Reduced Motion</span>
                  <span className="text-[11px] text-slate-400">
                    Minimize ambient backdrop transitions and particle effects
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next = accountPreferences.motionPreference === 'standard' ? 'reduced' : 'standard';
                    updateAccountPreferences({ motionPreference: next });
                    notify(`Motion preference set to ${next}.`);
                  }}
                  aria-pressed={accountPreferences.motionPreference === 'reduced'}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    accountPreferences.motionPreference === 'reduced'
                      ? 'bg-luminous-cyan'
                      : 'bg-obsidian-card'
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      accountPreferences.motionPreference === 'reduced' ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-xl bg-obsidian-surface border border-white/5">
                <div>
                  <span className="text-xs font-semibold text-white block">Compact Shelf Mode</span>
                  <span className="text-[11px] text-slate-400">
                    Display denser movie card grids across discover and library surfaces
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next = !accountPreferences.compactMode;
                    updateAccountPreferences({ compactMode: next });
                    notify(`Compact mode ${next ? 'enabled' : 'disabled'}.`);
                  }}
                  aria-pressed={accountPreferences.compactMode}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    accountPreferences.compactMode ? 'bg-luminous-cyan' : 'bg-obsidian-card'
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      accountPreferences.compactMode ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </GlassPanel>

          {/* Privacy & Sanctuary Controls */}
          <GlassPanel elevation="plate" padding="lg" rounded="2xl" className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-5 h-5 text-luminous-teal" />
              <h3 className="font-editorial text-xl font-bold text-white">
                Data Sanctity & Privacy
              </h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Veya Luma is an independent personalized discovery platform. In Phase 1, all preferences, taste vectors, and library entries are maintained in local development memory. We do not monetize your taste data or sell preference vectors to advertising brokers.
            </p>

            <div className="space-y-3 pt-2 border-t border-white/10">
              <div className="flex items-center justify-between p-3 rounded-xl bg-obsidian-surface border border-white/5">
                <div>
                  <span className="text-xs font-semibold text-white block">Anonymous Diagnostic Telemetry</span>
                  <span className="text-[11px] text-slate-400">
                    Share anonymized latency and route diagnostic signals for local development simulation
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next = !accountPreferences.analyticsConsent;
                    updateAccountPreferences({ analyticsConsent: next });
                    notify(`Diagnostic telemetry ${next ? 'enabled' : 'disabled'}.`);
                  }}
                  aria-pressed={accountPreferences.analyticsConsent}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    accountPreferences.analyticsConsent ? 'bg-luminous-cyan' : 'bg-obsidian-card'
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      accountPreferences.analyticsConsent ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </GlassPanel>

          {/* Data Export & Wipe */}
          <GlassPanel elevation="plate" padding="lg" rounded="2xl" className="space-y-4">
            <h3 className="font-editorial text-xl font-bold text-white mb-1">
              Taste Vector Management
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Export your calibrated taste profile and viewing history or reset your personal vectors.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-white/10">
              <Button
                variant="outline"
                size="sm"
                leftIcon={<Download className="w-3.5 h-3.5" />}
                onClick={handleExportDNA}
              >
                {sessionSaved ? 'Export Ready' : 'Export Cinematic DNA (JSON)'}
              </Button>
              <Button
                variant="danger"
                size="sm"
                leftIcon={<Trash2 className="w-3.5 h-3.5" />}
                onClick={handleResetVectors}
              >
                {resetConfirmed ? 'Vectors Reset' : 'Reset Taste Vectors'}
              </Button>
            </div>
          </GlassPanel>
        </div>
      )}
    </PageContainer>
  );
};

export default AccountPage;
